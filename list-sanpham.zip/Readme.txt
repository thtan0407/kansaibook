Thư mục images: 
	- Giữ lại file background-product.svg
	- Hình sản phẩm kích thước tỉ lệ 1:1
Thư mục css:
	- File theme-style.css: Code mới ở cuối file bắt đầu từ line 2309
File index.html: 
	- Bắt đầu từ line 94